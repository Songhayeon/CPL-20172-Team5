#!/usr/bin/env python3
import subprocess
import sys

def Train():
    proc = subprocess.Popen(['/root/openface/util/align-dlib.py', '/root/dataset/data',
        'align', 'outerEyesAndNose',
        '/root/dataset/align/',
        '--size', '96'],
        stdout = subprocess.PIPE, stderr = subprocess.PIPE
        )
    out, err = proc.communicate()
    print('==========ALIGN THE IMAGE COMPLETE==========')
    proc = subprocess.Popen(['/root/openface/batch-represent/main.lua',
        '-outDir', '/root/dataset/embedding/',
        '-data', '/root/dataset/align/'],
        stdout = subprocess.PIPE, stderr = subprocess.PIPE
        )

    out, err = proc.communicate()
    print('==========EMBEDDING IMAGE COMPLETE==========')
    proc = subprocess.Popen(['rm', '/root/dataset/align/cache.t7'])

    out, err = proc.communicate()
    proc = subprocess.Popen(['/root/openface/demos/classifier.py', 'train', '/root/dataset/embedding/'],
                stdout=subprocess.PIPE, stderr = subprocess.PIPE)
    
    out, err = proc.communicate()
    print ("==========TRAIN IMAGES COMPLETE==========")


def Compare():
    dirname = '/root/dataset/'
    name = 'compare.jpg'
    dirname += name
    proc = subprocess.Popen(['/root/openface/demos/classifier.py',
        'infer', '/root/dataset/embedding/classifier.pkl',
        dirname], 
        stdout = subprocess.PIPE, 
        stderr = subprocess.PIPE
        )

    out, err = proc.communicate()
    name, confidence = out.split()
    print(name, confidence, dirname)

    return name, confidence, dirname
    

if __name__ == "__main__":
    while True:
        check = input("Insert input Data(I) or Training(T) or Compare(C) or QUIT(Q) : ")
#       if check == 'I':
#          detect.faceDetect()
        if check == 'T':
            Train()
        elif check == 'Q':
            break
        elif check == 'C':
            Compare()
        else:
            print("INPUT ERROR")

